package com.api.erpdistribuidora.dto;

public record ImagemRequest(Long produtoId, String nome) {}
