// src/main/java/com/api/erpdistribuidora/exception/RegraCategoriaInvalidaException.java
package com.api.erpdistribuidora.exception;

public class RegraCategoriaInvalidaException extends RuntimeException {
    public RegraCategoriaInvalidaException(String message) {
        super(message);
    }
}
