// src/main/java/com/api/erpdistribuidora/model/TipoCategoria.java
package com.api.erpdistribuidora.model;

public enum TipoCategoria { Departamento, Categoria }

