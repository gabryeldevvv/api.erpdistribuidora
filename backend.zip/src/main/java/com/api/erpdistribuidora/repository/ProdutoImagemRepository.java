package com.api.erpdistribuidora.repository;

import com.api.erpdistribuidora.model.ProdutoImagem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProdutoImagemRepository extends JpaRepository<ProdutoImagem, Integer> {}
