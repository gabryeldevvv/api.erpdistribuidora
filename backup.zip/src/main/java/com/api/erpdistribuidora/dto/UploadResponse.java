package com.api.erpdistribuidora.dto;

public record UploadResponse(
        String url,
        String path
) {}
