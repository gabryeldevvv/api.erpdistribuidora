package com.api.erpdistribuidora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErpdistribuidoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErpdistribuidoraApplication.class, args);
	}

}
